<?php

namespace App\Http\Controllers\admin;
use Codexshaper\WooCommerce\Facades\Category;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\FormCategoryRequest;


class CategoryController extends Controller
{
   public function index()
   {
    $limit = 10;
    $Category = Category::all( ['per_page'=>$limit])->all();


    return view('admin.Category.index',['Category'=>$Category]);

   }

   public function store(FormCategoryRequest $req)
   {

    // $file = file_get_contents( 'req->input_image' );
    // $url = 'http://your-blog.com/wp-json/wp/v2/media/';
    // $ch = curl_init();
    // $username = 'admin';
    // $password = 'Buildy@2021';
    // curl_setopt( $ch, CURLOPT_URL, $url );
    // curl_setopt( $ch, CURLOPT_POST, 1 );
    // curl_setopt( $ch, CURLOPT_POSTFIELDS, $file );
    // curl_setopt( $ch, CURLOPT_HTTPHEADER, [
    // 'Content-Disposition: form-data; ',
    // 'Authorization: Basic ' . base64_encode( $username . ':' . $password ),
    // ] );
    // echo base64_encode( $username . ':' . $password );
    // $result = curl_exec( $ch );
    // curl_close( $ch );
    // var_dump( json_decode( $result ) );

    $data=
    [
        'name'=>$req->name,
        'slug'=>'demo',
        'image'=>
        [
            "src"=> "/image/h1.png"
        ]

    ];

    $category = Category::create($data);

    return redirect()->back()->with('success', 'A New Category Has Been Successfully Created!');

   }
   public function create()
   {

    return view('admin.product.create');

   }
   public function edit($id)
   {

    return view('admin.product.edit');

   }

   public function delete($id)
   {

    $options = ['force' => true];
    $category = Category::delete($id, $options);

    return redirect()->back()->with('message', 'IT WORKS!');


   }



}
