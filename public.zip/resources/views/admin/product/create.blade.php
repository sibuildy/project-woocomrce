@extends('voyager::master')

@section('css')
    <style></style>
@stop

@section('page_title', 'Your title')

@section('page_header')
    <div class="container-fluid">
        <h1 class="page-title">

          create site
        </h1>


    </div>
    @include('voyager::multilingual.language-selector')
@stop

@section('content')
    <div class="page-content container-fluid">




    </div>
@stop
